"use client";
// VRishi Academy — Persona Review route stub.
// Design reference: Review.dc.html (design project). Tokens: app/globals.css.
// Wiring contract: handoff/portal-contract.md + session-schema.md.
export default function Review() {
  return (
    <div className="shell">
      {/* TODO: shared <Sidebar/> — mirror the DC nav */}
      <main className="content">
        <span className="eyebrow">VRishi Academy</span>
        <h1>Persona Review</h1>
        <p className="note">
          Stub route. Port the design from <code>Review.dc.html</code>. 5-persona evaluation + gap/risk/fix. Reference doc.
        </p>
        {/* TODO: implement per design reference and wire data/events */}
      </main>
    </div>
  );
}
