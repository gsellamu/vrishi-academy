"use client";
// VRishi Academy — VRishi’s Special Blogs route stub.
// Design reference: Blog.dc.html (design project). Tokens: app/globals.css.
// Wiring contract: handoff/portal-contract.md + session-schema.md.
export default function Blog() {
  return (
    <div className="shell">
      {/* TODO: shared <Sidebar/> — mirror the DC nav */}
      <main className="content">
        <span className="eyebrow">VRishi Academy</span>
        <h1>VRishi’s Special Blogs</h1>
        <p className="note">
          Stub route. Port the design from <code>Blog.dc.html</code>. First-party essays. Wire to CMS/markdown store.
        </p>
        {/* TODO: implement per design reference and wire data/events */}
      </main>
    </div>
  );
}
