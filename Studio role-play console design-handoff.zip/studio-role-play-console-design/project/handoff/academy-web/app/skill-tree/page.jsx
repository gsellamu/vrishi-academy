"use client";
// VRishi Academy — Skill Tree route stub.
// Design reference: SkillTree.dc.html (design project). Tokens: app/globals.css.
// Wiring contract: handoff/portal-contract.md + session-schema.md.
export default function SkillTree() {
  return (
    <div className="shell">
      {/* TODO: shared <Sidebar/> — mirror the DC nav */}
      <main className="content">
        <span className="eyebrow">VRishi Academy</span>
        <h1>Skill Tree</h1>
        <p className="note">
          Stub route. Port the design from <code>SkillTree.dc.html</code>. 18-node constellation, dual-XP, drill queue. Needs mastery store.
        </p>
        {/* TODO: implement per design reference and wire data/events */}
      </main>
    </div>
  );
}
