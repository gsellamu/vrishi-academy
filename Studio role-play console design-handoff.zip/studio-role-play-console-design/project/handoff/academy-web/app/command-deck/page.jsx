"use client";
// VRishi Academy — Command Deck route stub.
// Design reference: Portal.dc.html (design project). Tokens: app/globals.css.
// Wiring contract: handoff/portal-contract.md + session-schema.md.
export default function CommandDeck() {
  return (
    <div className="shell">
      {/* TODO: shared <Sidebar/> — mirror the DC nav */}
      <main className="content">
        <span className="eyebrow">VRishi Academy</span>
        <h1>Command Deck</h1>
        <p className="note">
          Stub route. Port the design from <code>Portal.dc.html</code>. Role modes, XP/rank, season pass. Needs progress store.
        </p>
        {/* TODO: implement per design reference and wire data/events */}
      </main>
    </div>
  );
}
