"use client";
// VRishi Academy — Public Media route stub.
// Design reference: PublicMedia.dc.html (design project). Tokens: app/globals.css.
// Wiring contract: handoff/portal-contract.md + session-schema.md.
export default function PublicMedia() {
  return (
    <div className="shell">
      {/* TODO: shared <Sidebar/> — mirror the DC nav */}
      <main className="content">
        <span className="eyebrow">VRishi Academy</span>
        <h1>Public Media</h1>
        <p className="note">
          Stub route. Port the design from <code>PublicMedia.dc.html</code>. News, YouTube, websites directory. Populate rows.
        </p>
        {/* TODO: implement per design reference and wire data/events */}
      </main>
    </div>
  );
}
