"use client";
// VRishi Academy — Persona Builder route stub.
// Design reference: PersonaBuilder.dc.html (design project). Tokens: app/globals.css.
// Wiring contract: handoff/portal-contract.md + session-schema.md.
export default function PersonaBuilder() {
  return (
    <div className="shell">
      {/* TODO: shared <Sidebar/> — mirror the DC nav */}
      <main className="content">
        <span className="eyebrow">VRishi Academy</span>
        <h1>Persona Builder</h1>
        <p className="note">
          Stub route. Port the design from <code>PersonaBuilder.dc.html</code>. Compose client → Room/Studio.
        </p>
        {/* TODO: implement per design reference and wire data/events */}
      </main>
    </div>
  );
}
