"use client";
// VRishi Academy — Client Preview route stub.
// Design reference: ClientPreview.dc.html (design project). Tokens: app/globals.css.
// Wiring contract: handoff/portal-contract.md + session-schema.md.
export default function ClientPreview() {
  return (
    <div className="shell">
      {/* TODO: shared <Sidebar/> — mirror the DC nav */}
      <main className="content">
        <span className="eyebrow">VRishi Academy</span>
        <h1>Client Preview</h1>
        <p className="note">
          Stub route. Port the design from <code>ClientPreview.dc.html</code>. Public "what a session feels like". Static.
        </p>
        {/* TODO: implement per design reference and wire data/events */}
      </main>
    </div>
  );
}
