"use client";
// VRishi Academy — Faculty route stub.
// Design reference: Faculty.dc.html (design project). Tokens: app/globals.css.
// Wiring contract: handoff/portal-contract.md + session-schema.md.
export default function Faculty() {
  return (
    <div className="shell">
      {/* TODO: shared <Sidebar/> — mirror the DC nav */}
      <main className="content">
        <span className="eyebrow">VRishi Academy</span>
        <h1>Faculty</h1>
        <p className="note">
          Stub route. Port the design from <code>Faculty.dc.html</code>. Case conference, mock-PSR examiner, console. Needs roster/LMS.
        </p>
        {/* TODO: implement per design reference and wire data/events */}
      </main>
    </div>
  );
}
