"use client";
// VRishi Academy — Technique Library route stub.
// Design reference: Techniques.dc.html (design project). Tokens: app/globals.css.
// Wiring contract: handoff/portal-contract.md + session-schema.md.
export default function Techniques() {
  return (
    <div className="shell">
      {/* TODO: shared <Sidebar/> — mirror the DC nav */}
      <main className="content">
        <span className="eyebrow">VRishi Academy</span>
        <h1>Technique Library</h1>
        <p className="note">
          Stub route. Port the design from <code>Techniques.dc.html</code>. Technique library + first-session timeline. Static.
        </p>
        {/* TODO: implement per design reference and wire data/events */}
      </main>
    </div>
  );
}
