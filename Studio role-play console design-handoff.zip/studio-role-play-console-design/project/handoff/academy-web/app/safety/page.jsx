"use client";
// VRishi Academy — Safety & Ethics route stub.
// Design reference: Safety.dc.html (design project). Tokens: app/globals.css.
// Wiring contract: handoff/portal-contract.md + session-schema.md.
export default function Safety() {
  return (
    <div className="shell">
      {/* TODO: shared <Sidebar/> — mirror the DC nav */}
      <main className="content">
        <span className="eyebrow">VRishi Academy</span>
        <h1>Safety & Ethics</h1>
        <p className="note">
          Stub route. Port the design from <code>Safety.dc.html</code>. Consent, contraindications, abreaction, sign-off gate.
        </p>
        {/* TODO: implement per design reference and wire data/events */}
      </main>
    </div>
  );
}
