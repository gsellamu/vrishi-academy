"use client";
// VRishi Academy — Session Prep route stub.
// Design reference: SessionPrep.dc.html (design project). Tokens: app/globals.css.
// Wiring contract: handoff/portal-contract.md + session-schema.md.
export default function SessionPrep() {
  return (
    <div className="shell">
      {/* TODO: shared <Sidebar/> — mirror the DC nav */}
      <main className="content">
        <span className="eyebrow">VRishi Academy</span>
        <h1>Session Prep</h1>
        <p className="note">
          Stub route. Port the design from <code>SessionPrep.dc.html</code>. Pre-flight readiness gate. Needs service pings.
        </p>
        {/* TODO: implement per design reference and wire data/events */}
      </main>
    </div>
  );
}
