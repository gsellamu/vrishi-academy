"use client";
// VRishi Academy — The Room route stub.
// Design reference: Room.dc.html (design project). Tokens: app/globals.css.
// Wiring contract: handoff/portal-contract.md + session-schema.md.
export default function Room() {
  return (
    <div className="shell">
      {/* TODO: shared <Sidebar/> — mirror the DC nav */}
      <main className="content">
        <span className="eyebrow">VRishi Academy</span>
        <h1>The Room</h1>
        <p className="note">
          Stub route. Port the design from <code>Room.dc.html</code>. 3D reactive console + teleprompter + voice. WebGL; TTS/avatar are stubs.
        </p>
        {/* TODO: implement per design reference and wire data/events */}
      </main>
    </div>
  );
}
