"use client";
// VRishi Academy — Resources route stub.
// Design reference: Resources.dc.html (design project). Tokens: app/globals.css.
// Wiring contract: handoff/portal-contract.md + session-schema.md.
export default function Resources() {
  return (
    <div className="shell">
      {/* TODO: shared <Sidebar/> — mirror the DC nav */}
      <main className="content">
        <span className="eyebrow">VRishi Academy</span>
        <h1>Resources</h1>
        <p className="note">
          Stub route. Port the design from <code>Resources.dc.html</code>. Books, articles, communities, tools directory.
        </p>
        {/* TODO: implement per design reference and wire data/events */}
      </main>
    </div>
  );
}
