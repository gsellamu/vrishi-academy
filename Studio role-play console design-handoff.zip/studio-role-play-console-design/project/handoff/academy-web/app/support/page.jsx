"use client";
// VRishi Academy — Support & Providers route stub.
// Design reference: Support.dc.html (design project). Tokens: app/globals.css.
// Wiring contract: handoff/portal-contract.md + session-schema.md.
export default function Support() {
  return (
    <div className="shell">
      {/* TODO: shared <Sidebar/> — mirror the DC nav */}
      <main className="content">
        <span className="eyebrow">VRishi Academy</span>
        <h1>Support & Providers</h1>
        <p className="note">
          Stub route. Port the design from <code>Support.dc.html</code>. Supervision, referral/crisis, business, platform help.
        </p>
        {/* TODO: implement per design reference and wire data/events */}
      </main>
    </div>
  );
}
