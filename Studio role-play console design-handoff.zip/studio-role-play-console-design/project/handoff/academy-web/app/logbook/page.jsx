"use client";
// VRishi Academy — Real-Rep Logbook route stub.
// Design reference: Logbook.dc.html (design project). Tokens: app/globals.css.
// Wiring contract: handoff/portal-contract.md + session-schema.md.
export default function Logbook() {
  return (
    <div className="shell">
      {/* TODO: shared <Sidebar/> — mirror the DC nav */}
      <main className="content">
        <span className="eyebrow">VRishi Academy</span>
        <h1>Real-Rep Logbook</h1>
        <p className="note">
          Stub route. Port the design from <code>Logbook.dc.html</code>. Real-rep ledger, milestones, refreshers. Needs records store.
        </p>
        {/* TODO: implement per design reference and wire data/events */}
      </main>
    </div>
  );
}
