"use client";
// VRishi Academy — Teleprompter route stub.
// Design reference: Teleprompter.dc.html (design project). Tokens: app/globals.css.
// Wiring contract: handoff/portal-contract.md + session-schema.md.
export default function Teleprompter() {
  return (
    <div className="shell">
      {/* TODO: shared <Sidebar/> — mirror the DC nav */}
      <main className="content">
        <span className="eyebrow">VRishi Academy</span>
        <h1>Teleprompter</h1>
        <p className="note">
          Stub route. Port the design from <code>Teleprompter.dc.html</code>. Variation #2 E/P lanes, SSML/NLP tags. Browser TTS placeholder — swap to ElevenLabs.
        </p>
        {/* TODO: implement per design reference and wire data/events */}
      </main>
    </div>
  );
}
